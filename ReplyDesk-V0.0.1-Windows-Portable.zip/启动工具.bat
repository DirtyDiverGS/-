@echo off
chcp 65001 >nul
title 回击台
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1" %*
if errorlevel 1 (
  echo.
  echo 启动失败，请把窗口中的错误信息截图。
  pause
)
