param([switch]$NoBrowser)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$address = [System.Net.IPAddress]::Loopback

function Send-Response {
    param($Stream, [int]$StatusCode, [string]$Reason, [string]$ContentType, [string]$Body)
    $bodyBytes = [System.Text.Encoding]::UTF8.GetBytes($Body)
    $header = "HTTP/1.1 $StatusCode $Reason`r`nContent-Type: $ContentType; charset=utf-8`r`nContent-Length: $($bodyBytes.Length)`r`nConnection: close`r`nCache-Control: no-store`r`n`r`n"
    $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($header)
    $Stream.Write($headerBytes, 0, $headerBytes.Length)
    $Stream.Write($bodyBytes, 0, $bodyBytes.Length)
    $Stream.Flush()
}

function Send-JsonError {
    param($Stream, [int]$StatusCode, [string]$Reason, [string]$Message)
    $body = @{ error = @{ message = $Message } } | ConvertTo-Json -Depth 4 -Compress
    Send-Response $Stream $StatusCode $Reason 'application/json' $body
}

function Read-Request {
    param($Stream)
    $headerBytes = New-Object 'System.Collections.Generic.List[byte]'
    while ($headerBytes.Count -lt 65536) {
        $value = $Stream.ReadByte()
        if ($value -lt 0) { break }
        $headerBytes.Add([byte]$value)
        $count = $headerBytes.Count
        if ($count -ge 4 -and $headerBytes[$count-4] -eq 13 -and $headerBytes[$count-3] -eq 10 -and $headerBytes[$count-2] -eq 13 -and $headerBytes[$count-1] -eq 10) { break }
    }
    if ($headerBytes.Count -eq 0) { return $null }

    $headerText = [System.Text.Encoding]::ASCII.GetString($headerBytes.ToArray())
    $lines = $headerText -split "`r`n"
    $requestParts = $lines[0] -split ' '
    if ($requestParts.Count -lt 2) { throw 'Invalid HTTP request.' }
    $headers = @{}
    for ($index = 1; $index -lt $lines.Count; $index++) {
        $separator = $lines[$index].IndexOf(':')
        if ($separator -gt 0) { $headers[$lines[$index].Substring(0, $separator).Trim().ToLowerInvariant()] = $lines[$index].Substring($separator + 1).Trim() }
    }

    $contentLength = 0
    if ($headers.ContainsKey('content-length')) { $contentLength = [int]$headers['content-length'] }
    $bodyBytes = New-Object byte[] $contentLength
    $offset = 0
    while ($offset -lt $contentLength) {
        $read = $Stream.Read($bodyBytes, $offset, $contentLength - $offset)
        if ($read -le 0) { break }
        $offset += $read
    }
    return @{
        Method = $requestParts[0].ToUpperInvariant()
        Path = ($requestParts[1] -split '\?')[0]
        Body = [System.Text.Encoding]::UTF8.GetString($bodyBytes, 0, $offset)
    }
}

$listener = New-Object System.Net.Sockets.TcpListener($address, 0)
try {
    $listener.Start()
} catch {
    Write-Host "Unable to start local server: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'Windows blocked local network access for PowerShell.'
    Read-Host 'Press Enter to exit'
    exit 1
}

$port = ([System.Net.IPEndPoint]$listener.LocalEndpoint).Port
$prefix = "http://127.0.0.1:$port/"
Write-Host "Reply Desk started: $prefix" -ForegroundColor Green
Write-Host 'Close this window to stop. API keys and input are not written to files.'
if (-not $NoBrowser) { Start-Process $prefix }

try {
    while ($true) {
        $client = $listener.AcceptTcpClient()
        try {
            $stream = $client.GetStream()
            $request = Read-Request $stream
            if ($null -eq $request) { continue }

            if ($request.Method -eq 'GET' -and ($request.Path -eq '/' -or $request.Path -eq '/index.html')) {
                $html = [System.IO.File]::ReadAllText((Join-Path $root 'index.html'), [System.Text.Encoding]::UTF8)
                Send-Response $stream 200 'OK' 'text/html' $html
                continue
            }

            if ($request.Method -eq 'POST' -and $request.Path -eq '/api/chat') {
                try {
                    $payload = $request.Body | ConvertFrom-Json
                    if ([string]::IsNullOrWhiteSpace($payload.apiKey) -or [string]::IsNullOrWhiteSpace($payload.endpoint) -or [string]::IsNullOrWhiteSpace($payload.model)) {
                        Send-JsonError $stream 400 'Bad Request' 'Endpoint, model, and API key are required.'
                        continue
                    }
                    $endpointUri = [Uri]$payload.endpoint
                    if ($endpointUri.Scheme -ne 'https' -and -not ($endpointUri.Scheme -eq 'http' -and $endpointUri.IsLoopback)) {
                        Send-JsonError $stream 400 'Bad Request' 'Use HTTPS. HTTP is allowed only for a loopback endpoint.'
                        continue
                    }
                    $upstreamUrl = $payload.endpoint.TrimEnd('/') + '/chat/completions'
                    $upstreamBody = @{ model=$payload.model; temperature=$payload.temperature; messages=$payload.messages } | ConvertTo-Json -Depth 12 -Compress
                    $headers = @{ Authorization = 'Bearer ' + $payload.apiKey }
                    $upstream = Invoke-WebRequest -UseBasicParsing -Uri $upstreamUrl -Method Post -Headers $headers -ContentType 'application/json; charset=utf-8' -Body ([System.Text.Encoding]::UTF8.GetBytes($upstreamBody))
                    if ($upstream.RawContentStream) {
                        if ($upstream.RawContentStream.CanSeek) { $upstream.RawContentStream.Position = 0 }
                        $responseReader = New-Object System.IO.StreamReader($upstream.RawContentStream, [System.Text.Encoding]::UTF8, $true)
                        $upstreamContent = $responseReader.ReadToEnd()
                        $responseReader.Close()
                    } else {
                        $upstreamContent = $upstream.Content
                    }
                    Send-Response $stream ([int]$upstream.StatusCode) 'OK' 'application/json' $upstreamContent
                } catch {
                    $message = $_.Exception.Message
                    if ($_.ErrorDetails.Message) { $message = $_.ErrorDetails.Message }
                    Send-JsonError $stream 502 'Bad Gateway' $message
                }
                continue
            }

            Send-JsonError $stream 404 'Not Found' 'Not found'
        } catch {
            if ($stream) { Send-JsonError $stream 500 'Internal Server Error' $_.Exception.Message }
        } finally {
            $client.Close()
        }
    }
} finally {
    $listener.Stop()
}
